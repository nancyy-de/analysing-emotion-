import React from 'react';
import EmotionAnalyzer from './components/EmotionAnalyzer';

const App: React.FC = () => {
  return <EmotionAnalyzer />;
};

export default App;
