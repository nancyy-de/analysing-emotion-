import React, { useState } from 'react';

const EmotionAnalyzer: React.FC = () => {
  const [text, setText] = useState('');
  const [emotion, setEmotion] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setEmotion(null);

    // Mock API logic
    setTimeout(() => {
      setEmotion("Happy");
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-indigo-200 flex items-center justify-center p-4">
      <div className="bg-white shadow-lg rounded-2xl p-6 max-w-lg w-full">
        <h1 className="text-2xl font-bold text-center text-indigo-700 mb-4">Emotion Analyzer</h1>

        <textarea
          className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-indigo-400"
          rows={5}
          placeholder="Enter your text here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />

        <button
          onClick={handleAnalyze}
          className="w-full mt-4 bg-indigo-600 text-white font-semibold py-2 rounded-lg hover:bg-indigo-700 transition-all"
        >
          {loading ? 'Analyzing...' : 'Analyze Emotion'}
        </button>

        {emotion && (
          <div className="mt-6 text-center text-lg font-medium text-gray-800">
            Detected Emotion: <span className="font-bold text-indigo-600">{emotion}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmotionAnalyzer;
